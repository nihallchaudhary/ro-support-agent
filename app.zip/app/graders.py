EPS_MIN = 0.001
EPS_MAX = 0.999


def safe_score(score):
    """Ensure score is strictly within (0,1)"""
    try:
        score = float(score)
    except:
        return EPS_MIN

    # remove floating precision issues
    score = round(score, 6)

    if score <= 0:
        return EPS_MIN
    if score >= 1:
        return EPS_MAX

    return score


def grade_hard(action):
    """
    Hard grader:
    - multi_issue detection
    - service booking
    - meaningful reply length
    """

    score = 0.1  # base score (never 0)

    # ✅ condition 1
    if hasattr(action, "issue_label") and action.issue_label == "multi_issue":
        score += 0.3

    # ✅ condition 2
    if hasattr(action, "book_service") and action.book_service:
        score += 0.3

    # ✅ condition 3
    if hasattr(action, "reply") and isinstance(action.reply, str) and len(action.reply) > 20:
        score += 0.29   # ⚠️ intentionally NOT 0.3 to avoid 1.0

    # ✅ final safe score
    final_score = safe_score(score)

    # 🔍 DEBUG (remove after successful submission if needed)
    print(f"[DEBUG] Raw score: {score} -> Final score: {final_score}")

    return final_score