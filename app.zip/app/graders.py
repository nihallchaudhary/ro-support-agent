def grade_easy(action):
    return 1.0 if action.issue_label == "pump_issue" else 0.0


def grade_medium(action):
    score = 0.0
    if action.issue_label == "filter_issue":
        score += 0.5
    if "filter" in action.reply.lower():
        score += 0.5
    return score


def grade_hard(action):
    score = 0.0
    if action.issue_label == "multi_issue":
        score += 0.4
    if action.book_service:
        score += 0.3
    if len(action.reply) > 20:
        score += 0.3
    return score