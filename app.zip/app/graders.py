def clamp(score):
    if score <= 0:
        return 0.01
    if score >= 1:
        return 0.99
    return score


def grade_easy(action):
    score = 0.9 if action.issue_label == "pump_issue" else 0.1
    return clamp(score)


def grade_medium(action):
    score = 0.1

    if action.issue_label == "filter_issue":
        score += 0.4

    if "filter" in action.reply.lower():
        score += 0.4

    return clamp(score)


def grade_hard(action):
    score = 0.1

    if action.issue_label == "multi_issue":
        score += 0.3

    if action.book_service:
        score += 0.3

    if len(action.reply) > 20:
        score += 0.3

    return clamp(score)