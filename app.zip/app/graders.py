# graders.py

# ✅ Use safe margin (IMPORTANT)
EPS = 0.01


# 🔥 UNIVERSAL CLAMP FUNCTION
def clamp(score):
    if score <= 0:
        return EPS
    if score >= 1:
        return 1 - EPS
    return score


# 🎯 Example grading functions (modify based on your tasks)

def grade_task_1(output, expected):
    # simple accuracy example
    if output == expected:
        score = 1
    else:
        score = 0

    return clamp(score)


def grade_task_2(output, expected):
    # partial scoring example
    score = 0

    if output:
        score += 0.5
    if output == expected:
        score += 0.5

    return clamp(score)


def grade_task_3(output, expected):
    # similarity-based example
    score = 0

    if isinstance(output, str) and isinstance(expected, str):
        if expected in output:
            score = 0.8
        else:
            score = 0.2

    return clamp(score)