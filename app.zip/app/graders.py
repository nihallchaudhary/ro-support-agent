# 🔥 UNIVERSAL CLAMP FUNCTION
def clamp(score):
    if score <= 0.0:
        return 0.01
    elif score >= 1.0:
        return 0.99
    return score


def grade_easy(action):
    score = 1.0 if action.issue_label == "pump_issue" else 0.0
    return clamp(score)


def grade_medium(action):
    score = 0.0

    if action.issue_label == "filter_issue":
        score += 0.5

    if "filter" in action.reply.lower():
        score += 0.5

    return clamp(score)


def grade_hard(action):
    score = 0.0

    if action.issue_label == "multi_issue":
        score += 0.4

    if action.book_service:
        score += 0.3

    if len(action.reply) > 20:
        score += 0.3

    return clamp(score)