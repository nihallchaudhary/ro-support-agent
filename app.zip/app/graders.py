# =========================
# SAFE GRADERS (STRICTLY BETWEEN 0 AND 1)
# =========================

def grade_easy(action):
    # NEVER return 0 or 1
    if action.issue_label == "pump_issue":
        return 0.9
    else:
        return 0.1


def grade_medium(action):
    score = 0.1  # base score (never 0)

    if action.issue_label == "filter_issue":
        score += 0.4

    if "filter" in action.reply.lower():
        score += 0.4

    # ensure < 1
    if score >= 1.0:
        score = 0.95

    return score


def grade_hard(action):
    score = 0.1  # base score (never 0)

    if action.issue_label == "multi_issue":
        score += 0.3

    if action.book_service:
        score += 0.3

    if len(action.reply) > 20:
        score += 0.3

    # ensure < 1
    if score >= 1.0:
        score = 0.95

    return score