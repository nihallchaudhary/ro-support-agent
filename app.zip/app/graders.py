def grade_easy(action):
    if action.issue_label == "pump_issue":
        return clamp(0.9)
    else:
        return clamp(0.1)


def grade_medium(action):
    score = 0.1

    if action.issue_label == "filter_issue":
        score += 0.4

    if "filter" in action.reply.lower():
        score += 0.4

    return clamp(score)


def grade_hard(action):
    score = 0.1

    if action.issue_label == "multi_issue":
        score += 0.3

    if action.book_service:
        score += 0.3

    if len(action.reply) > 20:
        score += 0.3

    return clamp(score)