from fastapi import FastAPI
from app.env import ROEnv
from app.models import ROAction

app = FastAPI()
env = ROEnv()

@app.post("/reset")
def reset(task: str = "easy"):
    env.set_task(task)
    return env.reset()

@app.post("/step")
def step(action: ROAction):
    return env.step(action)

@app.get("/state")
def state():
    return env.state()