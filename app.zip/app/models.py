from pydantic import BaseModel
from typing import List, Optional

class ROObservation(BaseModel):
    customer_query: str
    conversation_history: List[str]
    step_count: int

class ROAction(BaseModel):
    reply: str
    issue_label: str
    book_service: bool

class StepResult(BaseModel):
    observation: ROObservation
    reward: float
    done: bool
    info: dict