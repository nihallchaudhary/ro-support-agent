from app.models import ROObservation, ROAction, StepResult

class ROEnv:

    def __init__(self):
        self.state_data = None
        self.done = False
        self.max_steps = 5
        self.task = "easy"

    def set_task(self, task):
        self.task = task

    def reset(self):
        self.done = False

        if self.task == "easy":
            query = "Water is not coming from RO"
            answer = "pump_issue"

        elif self.task == "medium":
            query = "Water tastes bad"
            answer = "filter_issue"

        else:
            query = "RO is noisy and water flow is low"
            answer = "multi_issue"

        self.state_data = {
            "query": query,
            "correct_issue": answer,
            "history": [],
            "step": 0
        }

        return ROObservation(
            customer_query=query,
            conversation_history=[],
            step_count=0
        )

    def step(self, action: ROAction):
        if self.done:
            return StepResult(
                observation=self._get_obs(),
                reward=0.01,  # 🔥 FIX
                done=True,
                info={"error": "Episode finished"}
            )

        self.state_data["step"] += 1
        reward = 0.0

        if action.issue_label == self.state_data["correct_issue"]:
            reward += 0.5
        else:
            reward -= 0.2

        if len(action.reply) > 15:
            reward += 0.2

        if action.book_service:
            reward += 0.3

        # 🔥 STRICT RANGE FIX
        reward = max(0.01, min(0.99, reward))

        self.state_data["history"].append(action.reply)

        if self.state_data["step"] >= self.max_steps:
            self.done = True

        return StepResult(
            observation=self._get_obs(),
            reward=reward,
            done=self.done,
            info={}
        )

    def _get_obs(self):
        return ROObservation(
            customer_query=self.state_data["query"],
            conversation_history=self.state_data["history"],
            step_count=self.state_data["step"]
        )

    def state(self):
        return self.state_data