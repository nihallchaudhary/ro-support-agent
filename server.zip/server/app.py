from fastapi import FastAPI
from app.env import ROEnv
from app.models import ROAction
import uvicorn

app = FastAPI()
env = ROEnv()


@app.get("/")
def home():
    return {"message": "RO Support OpenEnv Server Running 🚀"}


@app.post("/reset")
def reset(task: str = "easy"):
    env.set_task(task)
    obs = env.reset()

    return {
        "state": {
            "issue": obs.customer_query,
            "history": [],
            "step": 0
        }
    }


@app.post("/step")
def step(action: dict):
    act = ROAction(
        reply=action.get("reply", "auto"),
        issue_label=action.get("issue_label", ""),
        book_service=action.get("book_service", False)
    )

    result = env.step(act)

    # 🔥 EXTRA SAFETY
    safe_reward = max(0.01, min(0.99, result.reward))

    return {
        "reward": safe_reward,
        "done": result.done,
        "state": {
            "issue": result.observation.customer_query,
            "history": result.observation.conversation_history,
            "step": result.observation.step_count
        }
    }


def main():
    uvicorn.run(app, host="0.0.0.0", port=7860)


if __name__ == "__main__":
    main()